﻿const express = require('express');
const authController = require('../controllers/authController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.post('/login', authController.login);
router.post('/refresh', authController.refresh);
router.get('/me', requireAuth, authController.me);
router.post('/logout', requireAuth, authController.logout);
router.post('/change-password', requireAuth, authController.changePassword);
router.post('/reset-password', requireAuth, authController.resetPassword);
router.put('/fcm-token', requireAuth, authController.updateFcmToken);

module.exports = router;
