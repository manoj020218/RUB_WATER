# FloodGuard VPS Backend GAP

Date: 2026-06-22
Owner: Codex

## Scope

This file tracks backend-side gaps found during the firmware/APK contract audit and the current implementation/deployment status.

## Status Summary

- Canonical MQTT topic base moved to `floodguard`: DONE
- Legacy `rub` MQTT ingestion compatibility retained: DONE
- Rich telemetry ingestion and persistence for APK fields: DONE
- Config push payload aligned with firmware `cmd: "config_update"`: DONE
- Dashboard response normalization for APK: DONE
- Config response normalization for APK: DONE
- Local regression seed data restored: DONE
- Automated backend tests: DONE
- VPS upload/deploy: DONE

## Implemented Backend Changes

- Changed canonical MQTT topic base from `rub` to `floodguard`.
- Retained dual-subscription compatibility for both:
  - `floodguard/<device>/...`
  - `rub/<device>/...`
- Added generic outbound device MQTT publisher and aligned config pushes to firmware:
  - `cmd: "config_update"`
  - alias keys such as `trigger_delay_s`, `clear_delay_s`, `rs485_enabled`, `switch_enabled`
- Expanded telemetry ingestion/storage to preserve:
  - `local_ip`, `api_server`, `mqtt_server`
  - `wifi_connected`, `mqtt_connected`
  - `sensor_logic_mode`
  - `zero_dist_mm`, `sensor_mount_height_mm`, `vmon_cal_factor`
  - RTU left/right online/state/relay/fault data
- Normalized dashboard responses for APK consumption:
  - `location`
  - `device`
  - `latest`
  - `heartbeat`
  - `config`
  - `incident`
- Normalized device-config responses for APK:
  - `trigger_delay_s`
  - `clear_delay_s`
  - `rs485_enabled`
  - `switch_enabled`
  - `sensor_logic_mode`
  - `version`
  - `reported_at`
- Restored local seed data for regression runs:
  - `RUB043`, `RUB057`, `RUB071`
  - matching `*-CTRL01` devices

## Verification

- `npm test`: PASS
- Regression suites passing:
  - API regression
  - MQTT ingestion regression

## Residual Notes

- VPS upload completed and `floodguard-api` was restarted successfully.
- In-memory datastore seed data is only for local/test startup, not field persistence.
